/*
 * Author:      Cheryllynn Walsh
 * Date  :      Oct 12, 2017
 * Purpose:     Survey class
 */

//Constructor for the Survey
function Survey(name,description,quesNum){

};


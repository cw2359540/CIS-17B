<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        //1) set up the server information
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "example";
        
        //2) establish a connection
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
            return;
        }
        
        //3) generate a query
        //              $sfields                                     $table        $condition        
        $sql = "SELECT ".'*'." FROM ".'jewelry;';//." WHERE ".;
        
        //4) query the server and close the connection
        $result = mysqli_query($conn, $sql);
        var_dump($result);
        if($result!=null){
            foreach($result as $row){
                foreach($row as $item){
                    echo '<span>'.$item.'</span></br>';
                }
            }        
        }
        else{
            echo 'Server returned nothing';
        }
        
        mysqli_close($conn);//close the connection on command
        ?>
        
        <script type="text/javascript">
            //Put whatever buttons or forms you need here both however copy past
            
            
        </script>
    </body>
</html>

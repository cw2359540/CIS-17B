<!DOCTYPE html>
<?php
    session_start();
    $_SESSION['name']="Cheryllynn, Shane, Colleen";
    echo 'The name I stored on the server is: '.$_SESSION['name'];
?>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title></title>
	<link href="layout.css" type="text/css" rel="stylesheet">
	
<style>
 	body {background-color: #f2f2f2;}
</style>

<style>
.quantity { 
	width: 55px; 
}
</style>

<script type="text/javascript" src="guest-functions.js"></script>
<script>
	
/***************Add updateCart**************/
function updateCartTotalQ()
{
	var qTot = 0;
	var q;
	for (var i=1; i<=4; i++) // I think, your cart empties every time because when you call this function, you set ALL products to zeroes!
	// may be you should update cart values ONLY on click "add to cart"?
	{
		q=parsentInt(locatStorage.getItem("q" + i));
		if(isNaN(q)) { q=0; }
		qTot += q;
	}
	if(qTot==0)
	{
		document.getElementById("divCartSummary").inner.HTML = "Your shopping cart is now <strong>empty</strong>!";
	}
	else if (qTot==1)
	{
		document.getElementById("divCartSummary").innerHTML = "Your Shopping cart currenlty contains <strong> 1 item! </strong>";
	}
	else
	{
		document.getElementById("diverCartSummary").innerHTML = "Your cart currenty contains <br><strong>" + qTot + "items!</strong>";
	}
}

/*************Add updateName*************/
function updateName()
{
	var form = document.forms[1]; // The form we are looking at
	if( typeof localStorage.fName != "undefined" ){ // If false then there is a name set if true there is not
		delete localStorage.fName; // Log out
		// Instead of coping and pasting we can just call the checkuser functuon since it doesnt actually log in or out
		checkUser();
	}
	else{
		// This is logging in code
		localStorage["fName"] = form.elements["fName"].value;
		// Set the new customer's name into local storage and
		// Redisplay the guest area using "set Guest" function
		setGuest( form.elements["fName"].value );
		// Should do it here too
		checkUser();
	}
	// Set the new customer's name into local storage and
 	// redisplay the guest area using "set Guest" function
}

/*************Add simpleCart_shipping()*************/
function proceedCart_shipping()
{
	// here is it! you call add2Cart for all products, even if they are 0! So you reset everything to 0, if 
	/*if(localStorage.getItem( "cart" ) !== null) 
	{
		add2Cart('q1');
		add2Cart('q2');
		add2Cart('q3');
		add2Cart('q4');
		//so we need to change it so if there is a 0 it removes the entry instead of doing nothing
		//still want to check that the cart has thing in though
	}*/
		window.location.href="cart.php"; //instead of just going to checkout lets make sure we store the items in the cart before they leave? yes

}

/*************Add EmptytheCart_empty()*************/
function EmptytheCart_empty()
{
	if(localStorage.getItem( "cart" ) !== null)
	{
		var cart = {};
		cart = JSON.stringify( cart );
		localStorage.setItem( "cart", cart );
	}
	document.getElementById('q1').value = 0;
	document.getElementById('q2').value = 0;
	document.getElementById('q3').value = 0;
	document.getElementById('q4').value = 0;
	localStorage.setItem( "cart", null );
}
//these functions are different
function add2Cart(product) // it could be just a number, 1, 2, etc, instead of q1, q2, etc. Then you can easily update "cart" array. Like cart[product] will be cart[1], etc.
{
    console.log('Called add2Cart with '+product+' parameter');
    var cartContents = localStorage.getItem( "cart" ); // to get an item, it should be set first somewhere..
	// If( localStorage.getItem( "cart" ) === null )  
	// If the cart is null, it should go here
    // I  think '!==' means the type is not equal to null & '===' the type is equal to null
	// It looks like cartContents is literally "null", not just null
	if( cartContents === null || typeof cartContents === 'undefined' )  //If the cart is null, it should go here
	{ //if doesnt exist
            console.log('inside null');
		var cart = {};
		value = document.getElementById( product ).value;
		cart[product] = parseInt( value ); // "product" is q1, q2, etc, whatever user ordered. So how can you say cart[q1]??? it should be cart[1] then
		// what if you pass 2 arguments (q, 1) , instead of 1 (q1, etc)
		if( value > 0 ){ //if its more than 0
			localStorage.setItem( "cart", JSON.stringify( cart ) );
                        console.log(JSON.parse( localStorage.getItem( "cart" ) ));
		}
		// That would never occur because it is setting it if it doesnt exist in this if
	} else {
            console.log('inside not null');
                var cart=[];
		cart = JSON.parse( localStorage.getItem( "cart" ) );
		value = document.getElementById( product ).value;
		cart[product] = parseInt( value ); // if product is "q1", then cart[q1] will not work... ahould be cart[1], should be a number in []
		if( value > 0 ){ //if its more than 0
			localStorage.setItem( "cart", JSON.stringify( cart ) );
		}
		else if ( value == 0 ){
			delete cart[product]; //delete the product in the cart
			//then store it	
			localStorage.setItem( "cart", JSON.stringify( cart ) );	
		}
	}
// Add the indicated product quantity to the cart
// The updated quantity goes to local storage so
// the cart page will see it later when visited
}

function clearCart()
{
	localStorage.setItem('q1' , '0');
	localStorage.setItem('q2' , '0');
	localStorage.setItem('q3' , '0');
	localStorage.setItem('q4' , '0');
	updateCarTotalQ(0);

// Zero out all cart items using local storage
// so that all pages recognize cart is now empty
}

/************Add imageHover************/
function imageHover(){

	console.log( this );
	this.src="add-to-cart-button2.jpg";
}

window.onload=checkUser; //setGuest;
</script>
		
</head>

<body>
<header><center><img src="bluelg.jpg" width="900" height="158" alt="My Company"/></center></header>
<nav>
<form id="form1" name="form1" method="post">
<p>Choose a page to visit:<br>
  <select name="select" id="select" onchange="window.location.href=this.value;">
    <option value="index.php">Home</option>
	<option value ="game.php">Game</option>
	<option value ="characters.php">Characters</option>
	<option value="survey.php">Survey</option>
    <option value="shop.php" selected="selected">Shop</option>
    <option value="cart.php">Cart</option>
 	<option value="checkout.php">Checkout</option>
  </select>
</p>
</form>

<p><strong>Welcome <span id="divGuestArea">Guest</span>!</strong></p>
<form method="GET" action="LoginServlet.php">
  <div id="loginInput">
  <p>Enter your name:<input type="text" name="fName" size="20"></p>
  </div>
  <p><input type="submit" value="Sign-In" id="signInButton" onclick="updateName()"/></p>
  
</form>
<p>&nbsp;</p>

<div id="divGuestArea">&nbsp;</div>
</nav>

<div id="main">
<h1>Shop Your New Maze Game</h1>
<blockquote>
  <p> Attention shoppers! If you see what you like -all you have to do is click "Add to Cart' button. If you want more of our products - all you have to do is click <br /> 'Quantity' arrow up until your preferred quantity and click 'Add to Cart' button.</p>
</blockquote>
<table border="1" cellspacing="0" cellpadding="6">
  <tbody>
    <tr>
      <td><img src="maze01.gif" width="400" height="400" alt="generic product 1"/></td>
      <td><h3>Maze Box Puzzle</h3>
	  <p>Very high challenge skill required.</p></td>
      <td>Price:<br>$10.00</td>
      <td>
        <label for="q1">Quantity:<br></label>
        <input type="number" name="q1" id="q1" class="quantity" value="0"></td>
      <td><img src="add-to-cart-button1.gif" width="150" height="36" alt="add to cart button" onmouseout="this.src='add-to-cart-button1.gif';" onmouseover="this.src='add-to-cart-button2.jpg';" onclick="add2Cart('q1')" production_1/></td>
    </tr>
    <tr>
      <td><img src="mazetree02.gif" width="400" height="400" alt="generic product 2"/></td>
      <td><h3>Mazetree Puzzle</h3>
        <p>Moderate challenge someskill.<br>
        </p></td>
      <td>Price:<br>$5.00</td>
      <td><label for="q2">Quantity:<br></label>
        <input type="number" name="q2" id="q2" class="quantity" value="0"></td>
      <td><img src="add-to-cart-button1.gif" width="150" height="36" alt="add to cart button" onmouseout="this.src='add-to-cart-button1.gif';" onmouseover="this.src='add-to-cart-button2.jpg';" onclick="add2Cart('q2')" /></td>
    </tr>
    <tr>
      <td><img src="maze03.gif" width="400" height="400" alt="generic product 3"/></td>
      <td><h3>Maze Tall Puzzle</h3>
        <p> Moderate challenge some skill.
        <h5><em> *Good metnal exercise. Cool!</em></h5></p></td>
      <td>Price:<br>$4.25</td>
      <td><label for="q3">Quantity:<br></label>
        <input type="number" name="q3" id="q3" class="quantity" value="0"></td>
      <td><img src="add-to-cart-button1.gif" width="150" height="36" alt="add to cart button" onmouseout="this.src='add-to-cart-button1.gif';" onmouseover="this.src='add-to-cart-button2.jpg';" onclick="add2Cart('q3')" /></td>
    </tr>
    <tr>
      <td><img src="mazehart04.gif" width="400" height="400" alt="generic product 4"/></td>
      <td><h3>Maze Heart Puzzle</h3> 
	  <p>Beginning challenge beginning skill.</p></td>
      <td>Price:<br>$2.00</td>
      <td><label for="q4">Quantity:<br></label>
        <input type="number" name="q4" id="q4" class="quantity" value="0"></td>
      <td><img src="add-to-cart-button1.gif" width="150" height="36" alt="add to cart button" onmouseout="this.src='add-to-cart-button1.gif';" onmouseover="this.src='add-to-cart-button2.jpg';" onclick="add2Cart('q4')" /></td>
    </tr>
          <?php
        //1) set up the server information
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "beads";
		
        //2) establish a connection
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
            return;
        }
        
        //3) generate a query
        //              $sfields                                     $table        $condition        
        $sql = "SELECT ".'*'." FROM ".'jewelry'." WHERE ".'id_jewelry>1;';
        
        //4) query the server and close the connection
        $result = mysqli_query($conn, $sql);
        //$result is a 2d array where it stores x=>row items, y=> rows
        echo '<tr>';
        if($result!=null){
            foreach($result as $row){
                echo '<tr>';
                $no_print=true;
                foreach($row as $item){
                    if($no_print){
                        //don't print the id number
                        $no_print=false;
                    }
                    else{
                        echo '<td>'.$item.'</td>';
                    }
                }
                echo '</tr>';
            }        
        }
        else{
            echo 'Server returned nothing';
        }
        
        mysqli_close($conn);//close the connection on command
        ?>
    
    <tr>
      <td colspan="6" align="right"><form><input type="button" value="Update & Go to Cart" onclick="proceedCart_shipping();">&nbsp; &nbsp; &nbsp;<br> <br>
	  <!--When you click the proceed button, proceedCart_shipping function is called ...-->
      <input type="button" value="Empty the Cart" onclick="EmptytheCart_empty();">&nbsp; &nbsp; &nbsp;</form>
	  <form action="survey.php" method="get">
		<br><input type="submit" name="Back" value="Back" />
		&nbsp; &nbsp; &nbsp;
		</form>

	  
      </td>
      </tr>
  </tbody>
</table>
<footer><center>
Copyright © 2017 Shane, Colleen, and Cheryllynn
</center></footer>
</div>
</body>
</html>
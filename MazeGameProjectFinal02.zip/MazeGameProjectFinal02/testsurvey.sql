SELECT 
    entity_question.question, 
    entity_answers.answer
FROM
    entity_question
INNER JOIN
     xref_questions_answers ON entity_question.id_question = xref_questions_answers.quest_id
INNER JOIN
    entity_answers ON xref_questions_answers.ans_id = entity_answers.answer_id
WHERE
    xref_questions_answers.quest_id = 1 
    
    
<!DOCTYPE html>
<?php
    session_start();
    $_SESSION['name']="Cheryllynn, Shane, Colleen";
    echo 'The name I stored on the server is: '.$_SESSION['name'];
?>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Cheryllynn Walsh Survey</title>
	<link href="layout.css" type="text/css" rel="stylesheet">
	<script type="text/javascript" src="guest-functions.js"></script>
<style>
 	body {background-color: #f2f2f2;}
</style>

<style>
.quantity { 
	width: 55px;
}
</style>

<script>
window.onload=checkUser; //setGuest;
</script>

</head>

<body>
<header><center><img src="bluelg.jpg" width="900" height="158" alt="My Company"/></center></header>
<nav>
<form id="form1" name="form1" method="post">

<p>Choose a page to visit:<br>
  <select name="select" id="select" onchange="window.location.href=this.value;">
    <option value="index.php">Home</option>
	<option value ="game.php">Game</option>
	<option value ="characters.php">Characters</option>
	<option value ="survey.php" selected="selected">Survey</option> 
    <option value="shop.php">Shop</option>
    <option value="cart.php">Cart</option>
 	<option value="checkout.php">Checkout</option>
  </select>
</p>
</form>

<p><strong>Welcome <span id="divGuestArea">Guest</span>!</strong></p>
<form method="GET" action="LoginServlet.php">
  <div id="loginInput">
  <p>Enter your name:<input type="text" name="fName" size="20"></p>
  </div>
  <p><input type="button" value="Sign-In" id="signInButton" onclick="updateName()"/></p>
  
</form>
<p>&nbsp;</p>


</nav>
<body>
<div id="main">
<h1>Survey</h1>
<p>Category-Priority-Number</p>
<p>Questions</p>

<?php
        //1) set up the server information
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "survey";
        
        //2) establish a connection
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
            return;
        }
        
        //3) generate a query
        //              $sfields                                     $table        $condition        
        $sql = "SELECT * FROM survey.entity_question";//you will need to change later ok
        
        //4) query the server and close the connection
        $result = mysqli_query($conn, $sql);
        //$result is a 2d array where it stores x=>row items, y=> rows
        echo '<div>';//you need to put a tr inside a table tag for it to work
        if($result!=null){
			$number = 1;
			while ( $question = $result->fetch_assoc() ){
				//print out the question
				echo '<p class="question">' . $number . '. ' . $question['question'] . '</p>';
				//print out the answers
				
				$query = "SELECT entity_question.id_question, entity_question.question, entity_answers.answer FROM entity_question INNER JOIN xref_questions_answers ON entity_question.id_question = xref_questions_answers.quest_id INNER JOIN entity_answers ON xref_questions_answers.ans_id = entity_answers.answer_id WHERE xref_questions_answers.quest_id = "
				. $question['id_question'] ; //have to make sure to get the answers for the right question. and that is pretty darn close to being good. just gotta input more of those answers into the data base
				//also remember if you copy from word, it carries over that a. b. so i just erase em
				$answerResult = mysqli_query($conn, $query);
				//because we erase what was in results
				if( $answerResult->num_rows > 0){ //if we got something
					echo '<ul class="answers">';
					$letter = 'a';
					while ( $answer = $answerResult->fetch_assoc() ) {
						echo $letter; //this is our letter abcde
						echo '<input type="radio" name="q' . $number . '"  value="' . $letter . '">';
						echo '<label for="q' . $number . '">'  . $answer['answer'] . '</label><br/>';
						$letter++;
					}
					echo '</ul>';
					//because we need to close this result
					//here is why. you are using the procedaul approach
					//where i use a class approach so i can do those thats all
					mysqli_free_result ( $answerResult );
				}
				$number++;
			}
		}
		else{
            echo 'Server returned nothing';
        }
		//alright that was alot do you have questions
		echo "</div>";//once you open a table you need to close a table
        
        mysqli_close($conn);//close the connection on command
		
		/*
		keeping it safe here
		
		this querys the answers for the question		
SELECT 
entity_question.question, 
entity_answers.answer
FROM
entity_question
INNER JOIN
xref_questions_answers ON entity_question.id_question = xref_questions_answers.quest_id
INNER JOIN
entity_answers ON xref_questions_answers.ans_id = entity_answers.answer_id
WHERE
xref_questions_answers.quest_id = 1 
		
		querys the questions
SELECT 
entity_question.id_question,
entity_question.question
FROM
survey.xref_surv_question,
entity_question
WHERE
xref_surv_question.id_question = entity_question.id_question
AND
xref_surv_question.id_survey = 1

    */
        ?>
<!--
<p class="question">1. If your Raspberry Pi touch screen is upside-down on the case what is best file for you edit?</p>
<ul class="answers">            
<input type="radio" name="q1" value="a" id="q1a"><label for="q1a">a. /etc/skel/shells</label><br/>          
<input type="radio" name="q1" value="b" id="q1b"><label for="q1b">b. /boot/rc1/screen</label><br/>            
<input type="radio" name="q1" value="c" id="q1c"><label for="q1c">c. /boot/ipconfig/screen</label><br/>            
<input type="radio" name="q1" value="d" id="q1d"><label for="q1d">d. /config/txt</label><br/>
<input type="radio" name="q1" value="e" id="q1e"><label for="q1e">e. /config/screen</label><br/>
</ul>        


<p class="question">2. What is the best code you type to make the Raspberry Pi touch screen show right side up on the case?</p>        

<ul class="answers">            
<input type="radio" name="q2" value="a" id="q2a"><label for="q2a">a.screen=rightsideup</label><br/>           
<input type="radio" name="q2" value="b" id="q2b"><label for="q2b">b. lcd_rotate=180</label><br/>            
<input type="radio" name="q2" value="c" id="q2c"><label for="q2c">c. lcd_rotate=90</label><br/>           
<input type="radio" name="q2" value="d" id="q2d"><label for="q2d">d. lcd_rotate=2</label><br/>
<input type="radio" name="q2" value="e" id="q2e"><label for="q2e">e. lcd_rotate=4</label><br/>  
</ul>        

<p class="question">3. What command is the best to edit text file for Raspberry Pi touch screen?</p>        

<ul class="answers">            
<input type="radio" name="q3" value="a" id="q3a"><label for="q3a">a. edit /boot/ipconfig/txt</label><br/>            
<input type="radio" name="q3" value="b" id="q3b"><label for="q3b">b. sudo nano /boot/config.txt</label><br/>            
<input type="radio" name="q3" value="c" id="q3c"><label for="q3c">c. edith nano /boot/screen.txt</label><br/>           
<input type="radio" name="q3" value="d" id="q3d"><label for="q3d">d. sudo nano boot /screen.txt</label><br/>
<input type="radio" name="q2" value="e" id="q2e"><label for="q2e">e. sudo nano edit /boot/screen.txt</label><br/> 
</ul>        

<p class="question">4. What is better to see the Raspberry Pi?</p>        

<ul class="answers">           
<input type="radio" name="q4" value="a" id="q4a"><label for="q4a">a. 13 inch laptop</label><br/>            
<input type="radio" name="q4" value="b" id="q4b"><label for="q4b">b. 5 inch touch screen</label><br/>            
<input type="radio" name="q4" value="c" id="q4c"><label for="q4c">c. 19 inch monitor</label><br/>            
<input type="radio" name="q4" value="d" id="q4d"><label for="q4d">d. 40 inch TV</label><br/>        
</ul>        

<p class="question">5. What is your favorite raspberry Pi?</p>        

<ul class="answers">            
<input type="radio" name="q5" value="a" id="q5a"><label for="q5a">a. Raspberry Pi Model A+</label><br/>            
<input type="radio" name="q5" value="b" id="q5b"><label for="q5b">b. Raspberry Pi Model B+</label><br/>            
<input type="radio" name="q5" value="c" id="q5c"><label for="q5c">c. Raspberry Pi 2 Model B</label><br/>           
<input type="radio" name="q5" value="d" id="q5d"><label for="q5d">d. Raspberry Pi 3 Model B</label><br/>
<input type="radio" name="q2" value="e" id="q2e"><label for="q2e">e. Raspberry Pi Zero</label><br/>
<input type="radio" name="q2" value="f" id="q2f"><label for="q2f">f. Raspberry Pi Zero W</label><br/>
</ul>        

<p class="question">6. What programming language do you like best?</p>        

<ul class="answers">            
<input type="radio" name="q6" value="a" id="q6a"><label for="q6a">a. Java</label><br/>            
<input type="radio" name="q6" value="b" id="q6b"><label for="q6b">b. C++</label><br/>            
<input type="radio" name="q6" value="c" id="q6c"><label for="q6c">c. Python</label><br/>            
<input type="radio" name="q6" value="d" id="q6d"><label for="q6d">d. PHP</label><br/>
<input type="radio" name="q2" value="e" id="q2e"><label for="q2e">e. Perl</label><br/>
</ul>    

<p class="question">7.	What browser is best for you to use?</p>        

<ul class="answers">            
<input type="radio" name="q7" value="a" id="q7a"><label for="q7a">a. FireFox</label><br/>            
<input type="radio" name="q7" value="b" id="q7b"><label for="q7b">b. Chrome</label><br/>            
<input type="radio" name="q7" value="c" id="q7c"><label for="q7c">c. Opera</label><br/>            
<input type="radio" name="q7" value="d" id="q7d"><label for="q7d">d. Safari</label><br/>
<input type="radio" name="q2" value="e" id="q2e"><label for="q2e">e. Internet Explorer</label><br/>
</ul>
-->
<!-- <p><input type="button" value="Submit" onClick="updateName();"  /></p> -->
<form action="survey.php" method="get">
<input type="submit" name="submit" value="Submit me!" />
</form>

<form action="shop.php" method="get">
<input type="submit" name="next" class="next btn btn-info" value="Next" />
</form>

</div>

<div class="nav-collapse collapse">

<footer><center>
Copyright © 2017 Shane, Colleen, and Cheryllynn
</center></footer>
</div>
</body>
</html>
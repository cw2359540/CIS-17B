<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Cheryllynn Walsh Survey</title>
	<link href="layout.css" type="text/css" rel="stylesheet">
	
<script type="text/javascript" src="guest-functions.js"></script>
    
<style>
 	body {background-color: #f2f2f2;}
</style>

<script>
window.onload=checkUser; //setGuest;
</script>
	<?php
    session_start();
    $_SESSION['name']="Cheryllynn, Shane, Colleen";
    echo 'The name I stored on the server is: '.$_SESSION['name'];
	?>
</head>

<body>

<header><center><img src="bluelg.jpg" width="900" height="158" alt="My Company"/></center></header>

<div id="openButton" onClick="location.href = 'shop.php';">
    <img src="open sign.jpg" alt="open sign" width="300" height="300" align="right"/>
    <p>Push open sign to begin shopping.</p>
</div>


<nav>
<form id="form1" name="form1" method="post">

<p>Choose a page to visit:<br>
  <select name="select" id="select" onchange="window.location.href=this.value;">
    <option value="index.php" selected="selected">Home</option>
	<option value ="game.php">Game</option>
	<option value ="characters.php">Characters</option>
	<option value="survey.php">Survey</option>
    <option value="shop.php">Shop</option>
    <option value="cart.php">Cart</option>
 	<option value="checkout.php">Checkout</option>
  </select>
</p>
</form>

<p><strong>Welcome <span id="divGuestArea">Guest</span>!</strong></p>
<form method="GET" action="LoginServlet.php">
  <div id="loginInput">
  <p>Enter your name:<input type="text" name="fName" size="20"></p>
  </div>
  <p><input type="button" value="Sign-In" id="signInButton" onclick="updateName()"/></p>
  
</form>
<p>&nbsp;</p>


</nav>

<center>
<div id="main">
<h1>Maze Game</h1>
<span class="navlink"><a href="game.php">Play</a></span> <br>
<span class="navlink"><a href="characters.php">Characters</a></span> <br>
<span class="navlink"><a href="instructions.php">Instructions</a></span> <br>
<span class="navlink"><a href="leaderboards.php">Leaderboards</a></span> <br>
</div>
<center>
 
  <footer><center>
Copyright © 2017 Shane, Colleen, and Cheryllynn
</center></footer>
</div>
</body>
</html>
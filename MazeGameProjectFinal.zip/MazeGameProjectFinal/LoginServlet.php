<?php 

//run the login code
header( 'Location: shop.html' );

?>